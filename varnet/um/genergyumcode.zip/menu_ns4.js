//UDMv2.1.1


// filter for undefined menus and essential variables

for (f=0;f<mainItem.length;f++) {
	if (!subProps[f]) { subProps[f] = new Array(mainItem[f][2],mainItem[f][3],mainItem[f][3]); }
	if (!subItem[f]) { subItem[f] = new Array; }
	}

if (absTOP>0) { absTOP = 0; }
if (absLEFT<0) { absLEFT = 0; }


// appreviated base image path
var bh = baseHREF;


// find the inner width and height of the browser window

var bWid = window.innerWidth; 
var bHeight = window.innerHeight;


// compensate for lack of scrollbar if applicable
var offsetCenter=true;
if (document.width >= innerWidth) { bWid-=16; offsetCenter=false; }



// find the nav width and horizontal space

var endSpace = 0;
var navSpace = 0;
for (j=0;j<mainItem.length;j++) { 
	mainItem[j][2]+=1;
	if (mainItem[j][1]=="") { mainItem[j][1]="&nbsp;"; }
	mainItem[j][2]-=1;
	if (mainItem[j][1]!="") { 
		navSpace+=mainItem[j][2]+bSIZE; 
		}
	}
endSpace = bWid-navSpace-bSIZE;

if (bWid>navSpace) { menuALIGN="left"; absLEFT=0; stretchMENU=false; showBORDERS=false; }


// find the nav height

var navHeight = fSIZE+4+vPADDING;
var actualHeight = navHeight+(bSIZE*2); 
if (bWid<navSpace) { navHeight-=2; actualHeight-=2; }


// find the subnav item height

var subnavHeight = sfSIZE+4+svPADDING;
var actualsubHeight = subnavHeight+(sbSIZE*2); 


// set values for different alignments

var stAdjust=0; var absRIGHT; var relLEFT; 

var ralign=false;
if (menuALIGN=="right") { 
	ralign=true;
	absRIGHT = absLEFT; 
	absLEFT = endSpace-absRIGHT;
	relLEFT = absLEFT;
	if (relLEFT>0) { relLEFT=0; }
	absLEFT=0; 
	}

var calign=false;
if (menuALIGN=="center") { 
	calign=true;
	absLEFT = parseInt(endSpace/2);
	if (offsetCenter) { absLEFT-=8; }
	relLEFT = absLEFT;
	if (relLEFT<0) { relLEFT=0; }
	absLEFT=0; 
	}

var lalign=false;
if (menuALIGN=="left") {
	lalign = true;
	absRIGHT = absLEFT;
	relLEFT = absLEFT; 
	if (stretchMENU&&absRIGHT>0) { stAdjust = absRIGHT+(2*bSIZE); }
	if (relLEFT<0) { relLEFT=0; }
	if (stretchMENU) { absLEFT=0; }
	}

var subLEFT = relLEFT;
if (ralign) { subLEFT-=absRIGHT; }
if (lalign) { subLEFT+=absRIGHT; }
	
// how many main nav items
var ntl = 0;
for (intl=0;intl<mainItem.length;intl++) { if (mainItem[intl][1]!="") { ntl++; }}

var cStyle = 'cursor:hand';


// do nothing
function doNothing() { }



// find background colors or images

var back_defs = new Array(mCOLOR,bCOLOR,rCOLOR,smCOLOR,sbCOLOR,srCOLOR);
var useIMG = new Array(false,false,false,false,false,false)
var backers = new Array;
var mainbacks = new Array;

for (b=0;b>6;b++) {
	backers[b] = 'bgcolor=' + back_defs[b];
	if ((back_defs[b].indexOf('.gif') != -1) || (back_defs[b].indexOf('.jpg') != -1) || back_defs[b]=='') { useIMG[b] = true; }
	if (useIMG[b]) { 
		backers[b] = 'background="' + bh + back_defs[b] + '"'; 
		}
	if (back_defs[b]=='') { backers[b]=''; } 
	}




// clear submenus

var previousId = 0;

function clearMenus(num) {
d.layers["grid"].visibility = "hide";
var subid = 'subnav' + previousId;
var shadid = 'shadow' + previousId;
if (shCOLOR!="") { d.layers[shadid].visibility = "hide"; }
d.layers[subid].visibility = "hide";
d.layers["mainnav"].document.layers[previousId].document.layers[0].document.layers[0].visibility="hide";
if ((bWid>(navSpace+bSIZE))||(stAdjust>0)) {
	if (!lalign||(lalign&&absRIGHT>0)) { d.layers["gridL"].visibility = "hide"; }
	if (!ralign||(ralign&&absRIGHT>0)) { d.layers["gridR"].visibility = "hide"; }
	}
previousId=0;
}

// open selected submenu

var num;
var gridOkay = false;

function openMenu(num) {
d.layers["grid"].visibility = "show";
var openid = 'subnav' + num;
var shadid = 'shadow' + num;
d.layers["mainnav"].document.layers[num].document.layers[0].document.layers[0].visibility = "show"; 	
for (l=0;l<subItem[num].length;l++) {
	document.layers[openid].document.layers[0].document.layers[l].document.layers[0].document.layers[0].document.layers[0].visibility="show"; 
	}
if (shCOLOR!=""&&subItem[num]!='') { d.layers[shadid].visibility = "show"; }
d.layers[openid].visibility = "show"; 
if ((bWid>(navSpace+bSIZE))||(stAdjust>0)) {
	if (!lalign||(lalign&&absRIGHT>0)) { d.layers["gridL"].visibility = "show"; }
	if (!ralign||(ralign&&absRIGHT>0)) { d.layers["gridR"].visibility = "show"; }
	}
previousId = num;
}




//alert("assemble main nav");

var tSTR='';

var tFrame = '<table cellpadding=0 cellspacing=0 border=0>';

// event capturing layer
tSTR+='<layer name="grid" top=0 left=0 width=' + bWid + ' height=' + bHeight + ' visibility=hide onmouseover="clearMenus()"></layer>';

// nav stretching
var nsColor = bCOLOR;
if (!showBORDERS) { nsColor = mCOLOR; }
var nsMColor = mCOLOR;


if (stretchMENU) { 
	if (useIMG[1]) {
		if (showBORDERS) { 
			tSTR+='<layer name="stretchnav" background='../um/%20%2B%20bh%20%2B%20bCOLOR%20%2B%20' top=' + absTOP + ' left=0 width=' + bWid + ' height=' + actualHeight + '>';
			} else {
			if (useIMG[0]) { tSTR+='<layer name="stretchnav" background='../um/%20%2B%20bh%20%2B%20mCOLOR%20%2B%20' top=' + absTOP + ' left=0 width=' + bWid + ' height=' + actualHeight + '>'; }
			else { tSTR+='<layer name="stretchnav" bgcolor=' +  mCOLOR + ' top=' + absTOP + ' left=0 width=' + bWid + ' height=' + actualHeight + '>'; }
			}
		} else {
		if (showBORDERS) { 
			tSTR+='<layer name="stretchnav" bgcolor=' +  bCOLOR + ' top=' + absTOP + ' left=0 width=' + bWid + ' height=' + actualHeight + '>';
			} else {
			if (useIMG[0]) { tSTR+='<layer name="stretchnav" background='../um/%20%2B%20bh%20%2B%20mCOLOR%20%2B%20' top=' + absTOP + ' left=0 width=' + bWid + ' height=' + actualHeight + '>'; }
			else { tSTR+='<layer name="stretchnav" bgcolor=' +  mCOLOR + ' top=' + absTOP + ' left=0 width=' + bWid + ' height=' + actualHeight + '>'; }
			}
		}
	if (useIMG[0]) { tSTR+='<layer background='../um/%20%2B%20bh%20%2B%20mCOLOR%20%2B%20' top=' + bSIZE + ' left=' + bSIZE + ' width=' + (bWid-(2*bSIZE)) + ' height=' + navHeight + '></layer>'; }
	else { tSTR+='<layer bgcolor=' + mCOLOR + ' top=' + bSIZE + ' left=' + bSIZE + ' width=' + (bWid-(2*bSIZE)) + ' height=' + navHeight + '></layer>'; }
	tSTR+='</layer>';
	} else if (showBORDERS) {
	if (useIMG[1]) {
		tSTR+='<layer name="stretchnav" background='../um/%20%2B%20bh%20%2B%20bCOLOR%20%2B%20' top=' + absTOP + ' left=0 width=' + bWid + ' height=' + actualHeight + '>';
		} else {
		tSTR+='<layer name="stretchnav" bgcolor=' +  bCOLOR + ' top=' + absTOP + ' left=0 width=' + bWid + ' height=' + actualHeight + '>';
		}	
	tSTR+='</layer>';
	}


// background layer
if (useIMG[1]) { tSTR+='<layer name="undernav" background='../um/%20%2B%20%20bh%20%2B%20bCOLOR%20%2B%20' top=' + absTOP + ' left=' + relLEFT + ' width=' + (navSpace+bSIZE) + ' height=' + actualHeight + '></layer>'; }
else { tSTR+='<layer name="undernav" bgcolor=' +  bCOLOR + ' top=' + absTOP + ' left=' + relLEFT + ' width=' + (navSpace+bSIZE) + ' height=' + actualHeight + '></layer>'; }

// open frame
tSTR+='<layer name="mainnav" top=' + absTOP + ' left=' + relLEFT + '><table cellpadding=0 cellspacing=' + bSIZE + ' border=0><tr>';

	
	
// links
var tempLink = new Array;
for (i=0;i<mainItem.length;i++) { 

	// find width of link layer to calculate text indentation
	var lc = 0;
	function findWidths(layerobj,layerWidth,layerHeight) {
	if (mainItem[lc][3]=="left") { layerobj.left=tINDENT; }
	if (mainItem[lc][3]=="center") { layerobj.left=parseInt((mainItem[lc][2]-layerWidth)/2); }
	if (mainItem[lc][3]=="right") { layerobj.left=(mainItem[lc][2]-layerWidth-tINDENT); }
	if (layerHeight>navHeight) { layerobj.top = parseInt((navHeight-layerHeight)/2)+vtOFFSET; }
	lc++;
	}
	
	// link layers
	tempLink[i]=mainItem[i][0];
	if(mainItem[i][1]!="") { 
		if (mainItem[i][0]=="") { 
			mainItem[i][0] = "javascript:doNothing()";
			tSTR+='<td ' + backers[1] + ' class=menubarTD height=' + (navHeight-(2*bSIZE)) + '><ilayer name="ilayer' + i + '"><layer onmouseover="clearMenus()\; openMenu(' + i + ')" width="' + (mainItem[i][2]) + '" height="' + navHeight + '" ' + backers[0] + ' name="container' + i + '"><layer name="roll' + i + '" ' + backers[2] + ' width="100%" height="100%" visibility=hide onmouseout="if(!keepLIT){this.visibility=\'hide\'}"><layer left=0 onload="findWidths(this,this.clip.right,this.clip.bottom)" visibility=show><a>' + mainItem[i][1] + '</a></layer></layer></layer></ilayer></td>'; 
			} else { 
			tSTR+='<td ' + backers[1] + ' class=menubarTD height=' + (navHeight-(2*bSIZE)) + '><ilayer name="ilayer' + i + '"><layer onmouseover="clearMenus()\; openMenu(' + i + ')" width="' + (mainItem[i][2]) + '" height="' + navHeight + '" ' + backers[0] + ' name="container' + i + '"><layer name="roll' + i + '" ' + backers[2] + ' width="100%" height="100%" visibility=hide onmouseout="if(!keepLIT){this.visibility=\'hide\'}"><layer left=0 onload="findWidths(this,this.clip.right,this.clip.bottom)" visibility=show><a href="../um/%27%20%2B%20mainItem%5Bi%5D%5B0%5D%20%2B%20%27" target="' + mainItem[i][4] + '">' + mainItem[i][1] + '</a></layer></layer></layer></ilayer></td>'; 
			}
		}
	}

// close frame
tSTR+='</tr></table></layer>';



// default cursor layer for non links
var subDefLeft = relLEFT+bSIZE;
for (i=0;i<mainItem.length;i++) { 
	if (tempLink[i]=="") { tSTR+='>layer name="defaultLayer' + i + '" top=' + (absTOP+bSIZE) + ' left=' + subDefLeft  + ' width=' + mainItem[i][2] + ' height=' + navHeight + ' onmouseover="clearMenus()\; openMenu(' + i + ')"></layer>'; }
	subDefLeft+=(mainItem[i][2]+bSIZE);
	}



// event gapturing grid
if ((bWid>(navSpace+bSIZE))||(stAdjust>0)) {
	if (ralign) { tSTR+='<layer name="gridL" visibility=hide top=' + absTOP + ' left=' + absLEFT + ' onmouseover="clearMenus()" height=' + navHeight + ' width=' + (endSpace-(bSIZE*2)-absRIGHT) + '></layer>'; }
	if (ralign&&absRIGHT>0) { tSTR+='<layer name="gridR" visibility=hide top=' + absTOP + ' left=' + (endSpace-absRIGHT+navSpace) + ' onmouseover="clearMenus()" height=' + navHeight + ' width=' + (absRIGHT-(bSIZE*2)) + '></layer>'; }
	if (lalign&&absRIGHT>0) { tSTR+='<layer name="gridL" visibility=hide top=' + absTOP + ' left=' + absLEFT + '><a href="javascript:doNothing()" onmouseover="clearMenus()" height=' + navHeight + ' width=' + absRIGHT + '></layer>'; }
	if (lalign) { tSTR+='<layer name="gridR" visibility=hide top=' + absTOP + ' left=' + (absRIGHT+navSpace) + ' onmouseover="clearMenus()" height=' + navHeight + ' width=' + (endSpace-absRIGHT) + '></layer>'; }
	if (calign) { 
		tSTR+='<layer name="gridL" visibility=hide top=' + absTOP + ' left=0 onmouseover="clearMenus()" height=' + navHeight + ' width=' + (endSpace/2) + '></layer>'; 
		tSTR+='<layer name="gridR" visibility=hide top=' + absTOP + ' left=' + (navSpace+(endSpace/2)) + ' onmouseover="clearMenus()" height=' + navHeight + ' width=' + (endSpace/2) + '></layer>'; 
		}
	}
	


// assemble submenus

var mSTR='';

var SUBabsLEFT=0;



// find width of link layer to calculate text indentation
var slc = 0;
function findSubWidths(lcount,sublayerobj,sublayerWidth,sublayerHeight) {
if (subProps[lcount][2]=="left") { sublayerobj.left=stINDENT; }
if (subProps[lcount][2]=="center") { sublayerobj.left=((subProps[lcount][0]-(2*sbSIZE))-sublayerWidth)/2; }
if (subProps[lcount][2]=="right") { sublayerobj.left=((subProps[lcount][0]-(2*sbSIZE))-sublayerWidth-stINDENT); }
if (sublayerHeight<subnavHeight) { sublayerobj.top = (subnavHeight-sublayerHeight)/2; }
slc++;
}




// find height of submenu layer to calculate drop shadow size
function findLayerHeight(sn,sh) {
if (shCOLOR!="") {
	shadowid = 'shadow' + sn;
	document.layers[shadowid].clip.bottom = sh;
	}
}



// cell rollout backup function
function subRollClear(mi) {
var subrollclear = 'subnav' + mi;
for (rc=0;rc>subItem[mi].length;rc++) {
	d.layers[subrollclear].document.layers[0].document.layers[rc].document.layers[0].document.layers[0].visibility="hide";
	}
}
	
	
for (count=0;count<mainItem.length;count++) {

	// find next submenu position
	if (count==0) { 
		SUBabsLEFT=relLEFT+bSIZE;
		}
	else SUBabsLEFT+=mainItem[(count-1)][2]+bSIZE;

	// specify edge alignemnt
	var actualLEFT = SUBabsLEFT+hOFFSET;
	if (subProps[count][1]=="right") { 
		actualLEFT = SUBabsLEFT-(subProps[count][0]-mainItem[count][2])-hOFFSET;
		}

	// drop shadow 
	var shBack = "bgcolor='"+shCOLOR+"'";
	if ((shCOLOR.indexOf('.gif') != -1) || (shCOLOR.indexOf('.jpg') != -1)) { shBack = "background='"+bh+shCOLOR+"'"; }
	if (shCOLOR!="") { mSTR+='>layer name="shadow' + count + '" visibility=hide top=' + (absTOP+actualHeight+vOFFSET+shSIZE) + ' left=' + (actualLEFT+shSIZE) + ' ' + shBack + ' width=' + subProps[count][0] + ' height=10></layer>'; }

	// compile cells
	if (subItem[count]!='') {
		mSTR+='<layer visibility=hide name="subnav' + count + '" top=' + (absTOP+actualHeight) + ' left=' + actualLEFT + '>';
		mSTR+='<layer top=' + vOFFSET + ' left=0 ' + backers[4] + ' onload="findLayerHeight(' + count + ',this.clip.bottom)"><table cellpadding=0 cellspacing=' + sbSIZE + ' border=0>'; 
		for (i=0;i<subItem[count].length;i++) { 
			if (subItem[count][i][0]!=''&&subItem[count][i][1]!='') {
				mSTR+='>tr><td><table cellpadding=0 cellspacing=0 border=0><tr><td class=SUBmenubarTD height=' + subnavHeight + '><ilayer name="subilayer' + count + i + '" width="' + (subProps[count][0]-(sbSIZE*2)) + '"><layer onmouseover="subRollClear(' + count + ')\; this.document.layers[0].visibility=\'show\'" width="' + (subProps[count][0]-(2*sbSIZE)) + '" height="' + subnavHeight + '" ' + backers[3] + ' name="subcontainer' + count + i + '"><layer name="subroll' + [count] + [i] + '" ' + backers[5] + ' width="100%" height="100%" visibility=hide onmouseout="this.visibility=\'hide\'\; this.document.layers[0].visibility=\'show\'"><layer name="sublink' + [count] + [i] + '" left=0 onload="findSubWidths(' + count + ',this,this.clip.right,this.clip.bottom)"><a href="../um/%27%20%2B%20subItem%5Bcount%5D%5Bi%5D%5B0%5D%20%2B%20%27" target="' + subItem[count][i][2] + '">' +  subItem[count][i][1] + '</a></layer></layer></layer></ilayer></td></tr></table></td></tr>';
				}
			}
		mSTR+='</table></layer></layer>';
		} else {
		mSTR+='<layer visibility=hide name="subnav' + count + '"></layer>';
		}

}
		

// resize / reload trap

function nsinit() { setTimeout("window.onresize = redo", 1000); }
function redo() { window.location.reload(); }
window.onload = nsinit;




// static positioning properties from Dynamic Drive
// http://www.dynamicdrive.com/dynamicindex1/staticmenu2.htm

var staticObj;
function makeStatic() {
eval(d.layers["grid"].top=eval(window.pageYOffset)); 
if (stretchMENU||showBORDERS) { eval(d.layers["stretchnav"].top=eval(window.pageYOffset+absTOP)); }
eval(d.layers["undernav"].top=eval(window.pageYOffset+absTOP)); 
eval(d.layers["mainnav"].top=eval(window.pageYOffset+absTOP)); 
if ((bWid>(navSpace+bSIZE))||(stAdjust>0)) {
	if (ralign||calign||(lalign&&absRIGHT>0)) { eval(d.layers["gridL"].top=eval(window.pageYOffset+absTOP)); }
	if (lalign||calign||(ralign&&absRIGHT>0)) { eval(d.layers["gridR"].top=eval(window.pageYOffset+absTOP)); }
	}
for (s=0;s<mainItem.length;s++) {
	staticObj = 'subnav' + s;
	shadowObj = 'shadow' + s;
	defaultObj = 'defaultLayer' + s;
	eval(d.layers[staticObj].top=eval(window.pageYOffset+absTOP+actualHeight)); 
	if (shCOLOR!="") { eval(d.layers[shadowObj].top=eval(window.pageYOffset+absTOP+actualHeight+shSIZE+vOFFSET)); }
	if (tempLink[s]=="") { eval(d.layers[defaultObj].top=eval(window.pageYOffset+absTOP+bSIZE)); }
	}
setTimeout("makeStatic()",0); 
}



// draw main nav 

d.write(tSTR);


// draw submenus

d.write(mSTR);




// static mode trigger
if (staticMENU==true||staticMENU=="safe") { makeStatic(); }
>