//UDMv2.1.1


var siSTR='';
if (ie) { siSTR+='<script language=javascript src="../um/menu_ie.js"></script>'; }
if (ns4) { siSTR+='<script language=javascript src="../um/menu_ns4.js"></script>'; }
if (ns6||mz7) { siSTR+='<script language=javascript src="../um/menu_ns6.js"></script>'; }
if (op5&&!mac) { siSTR+='<script language=javascript src="../um/menu_op5.js"></script>'; }
document.write(siSTR);	
	
